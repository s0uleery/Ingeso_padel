// src/custom.d.ts
declare module '*.css';
